import Link from 'next/link';

export default function Home() {
  return (
    <div className="w-full h-svh">
      <main className="h-full lg:flex items-center justify-center gap-10">
        <Link href="/sales/junior" className="flex flex-col items-center gap-5">
          <div className="size-20 rounded-full bg-white lg:size-50"></div>
          <div className='space-y-1'>
            <p className='font-medium text-center'>Camille Lellouche</p>
            <p className="text-neutral-700 text-xs text-center">Commercial junior</p>
          </div>
        </Link>
        <Link href="/sales/senior" className="flex flex-col items-center gap-5">
          <div className="size-20 rounded-full bg-white lg:size-50"></div>
          <div className='space-y-1'>
            <p className="font-medium text-center">Israel Adesanya</p>
            <p className="text-neutral-700 text-xs text-center">Commercial senior</p>
          </div>
        </Link>

        <Link href="/sales/senior" className="flex flex-col items-center gap-5">
          <div className="size-20 rounded-full bg-white lg:size-50"></div>
          <div className='space-y-1'>
            <p className="font-medium text-center">Stephane Ko</p>
            <p className="text-neutral-700 text-xs text-center">Recherche & Developpement</p>
          </div>
        </Link>
      </main>
    </div >
  );
}
