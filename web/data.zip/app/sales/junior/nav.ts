import {
  BookOpen,
  Building2,
  CalendarCheck,
  LayoutDashboard,
  type LucideIcon,
} from 'lucide-react';

export interface NavItem {
  href: string; // sert aussi de key React
  label: string;
  icon: LucideIcon;
  exact?: boolean; // actif seulement sur l'URL exacte
  alsoActiveOn?: string[]; // nouveau
}

export const juniorNav: NavItem[] = [
  {
    href: '/sales/junior',
    label: 'Tableau de bord',
    icon: LayoutDashboard,
    exact: true,
  },
  {
    href: '/sales/junior/clients',
    label: 'Portefeuille clients',
    icon: Building2,
    alsoActiveOn: ['/sales/junior/opportunites'],
  },
  {
    href: '/sales/junior/appointment',
    label: 'Rendez-vous',
    icon: CalendarCheck,
  },
  {
    href: '/sales/junior/good-practices',
    label: 'Bonnes pratiques',
    icon: BookOpen,
  },
];
